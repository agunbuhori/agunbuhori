<!DOCTYPE html>
<html>
<head>
	<title>Seniman Coding</title>
</head>
<body>
<div class="about">
<h1>Seniman Coding Web Framework</h1>
<h2>PHP, CSS, and Javascript Framework</h2>
<p>Buat web aman dan cepat. - Agun Buhori, Web Developer</p>
</div>
</body>
</html>
<style type="text/css">
	body
	{
		margin: 0;
		font-family: "Segoe UI";
		color: #777;
		font-size: 15px;
	}
	h2
	{
		font-weight: 100;
	}
	h1
	{
		font-size: 3em;
		text-align: center;
		font-weight: 100;
	}
	.about
	{
		margin-top: 100px;
		padding: 50px 10%;
		background: rgb(247,247,247);
		border-top: 1px solid rgb(226,226,226);
		border-bottom: 1px solid rgb(226,226,226);
		text-align: center;
	}
</style>