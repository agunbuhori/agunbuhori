<?php if(defined('BASEPATH')or exit('Access forbidden'));

	class Home extends Controller
	{

		function index()
		{
			$this->load->view('homeView');
		}

		function test()
		{

		}
	}