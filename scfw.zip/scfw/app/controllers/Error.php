<?php if(defined('BASEPATH')or exit('Access forbidden'));

	class Error extends Controller
	{

		function index()
		{
			echo "404";
		}

		function test()
		{

		}
	}