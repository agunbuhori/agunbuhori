<?php

	Class App
	{
		public function __construct()
		{
			session_start();
			//default handler

			$url = $this->parseUrl();
			$this->loadEngine();
			$this->getUserId();

			if(empty($url[0]) || !file_exists(APP.'controllers/'.$url[0].'.php'))
			{
				require(APP.'controllers/home.php');
				$run = new Home();
				if(empty($url[0]))
				{
					$run->index();
				}
				elseif(!empty($url[0]) && method_exists($run, $url[0]))
				{
					$run->$url[0]();
				}
				else
				{
					redirect('Error');
				}
			}
			elseif(file_exists(APP.'controllers/'.$url[0].'.php'))
			{
				require(APP.'controllers/'.$url[0].'.php');
				$run = new $url[0]();
				if(empty($url[1]))
				{
					$run->index();
				}
				elseif(!empty($url[1]) && method_exists($run, $url[1]))
				{
					$run->$url[1]();
				}
				else
				{
					redirect('Error');
				}
			}
		}

		private function parseUrl()
		{
			if(isset($_GET['url']))
			{
				$url = explode('/',$_GET['url']);
				return $url;
				unset($_GET['url']);
			}
		}

		private function getUserId()
		{
			if(!isset($_SESSION['id']))
			{
				$_SESSION['id'] = rand(000000,999999);
			}
		}

		private function loadEngine()
		{
			require(APP.'config/database.php');
			require(BASEPATH.'system/database.php');
			require(BASEPATH.'system/controller.php');
			require(BASEPATH.'system/model.php');
			require(BASEPATH.'system/data.php');
			require(BASEPATH.'system/functions.php');
		}
	}

	class Load
	{
		public function model($param)
		{
			require(APP.'/models/'.$param.'.php');
		}

		public function library($param)
		{
			require(APP.'/libraries/'.$param.'.php');
		}

		public function view($param)
		{
			require(APP.'/views/'.$param.'.php');
		}
	}