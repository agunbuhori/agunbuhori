<?php

	class Data
	{

		public static function post($param)
		{
			return $_POST[$param];
		}

		public static function get($param)
		{
			return $_GET[$param];
		}

		public static function user($param)
		{
			return $_SESSION[$param];
		}
	}