<?php
	
	class Controller extends Database
	{
		protected $db;
		protected $load;

		public function __construct()
		{
			$this->db 	= new Database();
			$this->load = new Load();
		}
	}