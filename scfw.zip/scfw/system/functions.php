<?php

	/**
	/* all function here will help development
	*/

	/* the helper for get url */
	function url($param=null)
	{
		return 'http://localhost/bs/'.$param;
	}

	/* the helper for redirect url */
	function redirect($param=null)
	{
		header('location:'.url($param));
	}