<?php

	class Database extends PDO
	{
		private $type;
		private $host;
		private $user;
		private $pass;
		private $name;

		public function __construct()
		{
			$this->type = DB_TYPE;
			$this->host = DB_HOST;
			$this->user = DB_USER;
			$this->pass = DB_PASS;
			$this->name = DB_NAME;
			try{
				$this ->dbh = new PDO($this->type.":host=".$this->host.";dbname=".$this->name,$this->user,$this->pass);
				$this->dbh->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
			}catch(PDOException $e)
			{
				echo "Sudah membuat database? atau ada yang salah di sini :".$e->getMessage();
			}
		}

		protected function insert($table,$data)
		{
			$query = "INSERT INTO $table";
			$cols = null;
			$vals = null;
			foreach(array_keys($data) as $col)
			{
				$cols .= ",".$col;
				$vals .= ",?";
			}
			$query .= "(".substr($cols,1).")";
			$query .= " VALUES(".substr($vals,1).")";
			$stmt = $this->dbh->prepare($query);
			$stmt->execute(array_values($data));

		}

		protected function update($table,$data,$where)
		{
			$query = "UPDATE $table SET ";
			$sets = null;
			foreach($data as $col => $val)
			{
				if(substr($col,0,1) != "*")
				{
					$sets .= ",".$col."='".$val."'";
				}
				else
				{
					$sets .= ",".$col."=".$val;
				}
			}

			$query .= substr($sets,1);
			$stmt = $this->dbh->prepare($query);
			$stmt->execute();
		}

		protected function delete($table,$where)
		{
			$query = "DELETE FROM $table WHERE ";
			$wheres = null;
			foreach($where as $col => $val)
			{
				$wheres .= " AND ".$col."='".$val."'";
			}
			$query .= substr($wheres,5);
			$stmt = $this->db->prepare($query);
			$stmt->execute();
			echo $query;

		}

		protected function get($sql)
		{
			if(substr($sql,0,5) == "SELECT")
			{
				$query = $sql;
			}
			else
			{
				$query = "SELECT * FROM $table";
			}
			$this->query = $query;
			return $this;
		}

		protected function where($sql)
		{
			$this->query .= $sql;
			return $this;
		}

		protected function result()
		{
			$stmt = $this->dbh->prepare($this->query);
			$stmt->execute();
			return $stmt->fetchAll(PDO::FETCH_OBJ);
		}

		protected function num_rows()
		{
			$stmt = $this->dbh->prepare($this->query);
			$stmt->execute();
			return $stmt->rowCount();
		}

		public function __destruct()
		{
			$this->dbh = null;
		}
	}