<?php

/**
/* the constants are running on all engine
**/
define('BASEPATH',str_replace('\\','/',dirname(__FILE__)).'/');
define('APP',BASEPATH.'app/');


/**
/* runing default system
*/
require_once(BASEPATH.'system/app.php');
$app = new App();